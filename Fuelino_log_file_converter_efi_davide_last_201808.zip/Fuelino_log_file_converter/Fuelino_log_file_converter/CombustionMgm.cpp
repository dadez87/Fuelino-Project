#include "stdafx.h"

#define THROTTLE_MIN (unsigned short)112
#define THROTTLE_MAX (unsigned short)840

void export_COM_data_file(FILE *outfile) {
	fprintf(outfile, "SD Time [ms],");
	fprintf(outfile, "Inj Count,");
	fprintf(outfile, "Inj Start [us],");
	fprintf(outfile, "Inj End In [us],");
	fprintf(outfile, "Inj End Out [us],");
	fprintf(outfile, "Throttle,");
	//fprintf(outfile, "Lambda,");
	fprintf(outfile, "Throttle [%],");
	fprintf(outfile, "Lambda [V],");
	fprintf(outfile, "Inj Time [us],");
	fprintf(outfile, "Inj Increment [%],");
	fprintf(outfile, "Delta Time [us],");
	fprintf(outfile, "Eng Speed [rpm],");
	fprintf(outfile, "\n");
	CombustionMgm_class* Combustion_block_tmp_now = CombustionMgm_blocks_index; // Start from first element
	while (Combustion_block_tmp_now != nullptr) {
		fprintf(outfile, "%d,", Combustion_block_tmp_now->time_ms);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->injection_counter);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->inj_start_ticks);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->inj_end_in_ticks);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->inj_end_out_ticks);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->throttle_raw);
		//fprintf(outfile, "%d,", Combustion_block_tmp_now->lambda_raw);
		fprintf(outfile, "%f,", Combustion_block_tmp_now->throttle_perc);
		fprintf(outfile, "%f,", Combustion_block_tmp_now->lambda_volt);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->time_injection_input);
		//fprintf(outfile, "%d,", Combustion_block_tmp_now->time_injection_output);
		fprintf(outfile, "%f,", Combustion_block_tmp_now->injection_increment_perc);
		//fprintf(outfile, "%d,", Combustion_block_tmp_now->INJ_exec_time_1);
		//fprintf(outfile, "%d,", Combustion_block_tmp_now->INJ_exec_time_2);
		fprintf(outfile, "%d,", Combustion_block_tmp_now->time_between_injections);
		fprintf(outfile, "%f,", Combustion_block_tmp_now->rpm_cal);
		fprintf(outfile, "\n");
		Combustion_block_tmp_now = Combustion_block_tmp_now->next;
	}
}

CombustionMgm_class::CombustionMgm_class() {

}

// returns the delta time between 2 times (us)
unsigned long calculate_delta_time(long long t1_us, long long t2_us) {
	long long tmp_calc = t2_us - t1_us;
	if (tmp_calc < 0) tmp_calc += (1 << 32) * 4; // add rollover
	return tmp_calc;
}

// Analyzes the packets previously acquired
void COM_analyze_Combustion_messages() {
	long long inj_start_ticks_old = 0;
	CombustionMgm_class* Combustion_block_tmp_now = CombustionMgm_blocks_index; // Start from first element
	while (Combustion_block_tmp_now != nullptr) {
		Combustion_block_tmp_now->time_between_injections = calculate_delta_time(inj_start_ticks_old, Combustion_block_tmp_now->inj_start_ticks); // calculates ticks difference
		if (Combustion_block_tmp_now->time_between_injections) Combustion_block_tmp_now->rpm_cal = (double)120.0*1000000.0 / (double)Combustion_block_tmp_now->time_between_injections;
		inj_start_ticks_old = Combustion_block_tmp_now->inj_start_ticks; // overwrite old
		Combustion_block_tmp_now = Combustion_block_tmp_now->next;
	}
}

void CombustionMgm_class::parse_Combustion_message(unsigned char* buffer_temp) {

	time_ms = *((unsigned long*)&(buffer_temp[2])); // ms
	injection_counter = *((unsigned short*)&(buffer_temp[6])); // no unit;
	inj_start_ticks = *((unsigned long*)&(buffer_temp[8])) * 4; // us
	inj_end_in_ticks = *((unsigned long*)&(buffer_temp[12])) * 4; // us
	inj_end_out_ticks = *((unsigned long*)&(buffer_temp[16])) * 4; // us
	throttle_raw = *((unsigned short*)&(buffer_temp[20])); // 0-1023
	lambda_raw = *((unsigned short*)&(buffer_temp[22])); // 0-1023
	INJ_exec_time_1 = *((unsigned char*)&(buffer_temp[24])) * 4; //
	INJ_exec_time_2 = *((unsigned char*)&(buffer_temp[25])) * 4; //


	// Throttle raw voltage transformed into percentage
	if (throttle_raw <= THROTTLE_MIN) {
		throttle_perc = 0.0;
	}
	else if (throttle_raw >= THROTTLE_MAX) {
		throttle_perc = 100.0;
	}
	else {
		throttle_perc = ((double)(throttle_raw - THROTTLE_MIN))*(double)100.0 / (double)(THROTTLE_MAX - THROTTLE_MIN);
	}

	lambda_volt = (double)lambda_raw * 5.0 / (double)1023.0;

	time_injection_input = calculate_delta_time(inj_start_ticks, inj_end_in_ticks);
	time_injection_output = calculate_delta_time(inj_start_ticks, inj_end_out_ticks);
	time_injection_extension = time_injection_output - time_injection_input;
	if (time_injection_input) injection_increment_perc = (double)100.0*(double)time_injection_extension / (double)time_injection_input;

}

CombustionMgm_class* CombustionMgm_blocks_index = nullptr;