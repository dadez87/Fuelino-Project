#ifndef EngineMgm_h
#define EngineMgm_h

#define ECU_PACKET_LENGTH 25 // Ecu data packet size

class EngineMgm_class{

public:

	EngineMgm_class();
	void init_old_variables();
	void parse_ECU_packet(unsigned char* buffer_temp);
	void elaborate_raw_data();

	// Raw data
	unsigned int packet_cnt_raw; // 1
	unsigned long time_stamp_temp_raw; // 2
	unsigned short injection_counter_buffer_raw; // 6
	unsigned int inj_start_tick_last_raw; // 8
	unsigned int delta_time_tick_buffer_raw; // 10
	unsigned int delta_inj_tick_buffer_raw; // 12
	unsigned short throttle_buffer_raw; // 14
	unsigned short lambda_buffer_raw; // 16
	unsigned short extension_time_ticks_buffer_raw; // 18
	unsigned int INJ_exec_time_1_buffer_raw; // 20
	unsigned int INJ_exec_time_2_buffer_raw; // 21
	unsigned int digital_inputs_raw;// 22

	// Old variables
	double time_stamp_temp_old; // time stamp of previous sample
	unsigned short injection_counter_buffer_old; // injection number at previous sample
	unsigned int inj_start_tick_last_old; // start of injection last sample
	double time_last_injection; // time of last new injection
	double engine_speed_calc_old; // engine speed calculated at previous sample
	bool cutoff_mode; // this mode becomes active when brake is pressed (injection cut)

	// Modified data
	double time_stamp_temp; // s
	double throttle_buffer; // %
	double lambda_buffer; // V
	double engine_speed_calc; // rpm
	bool engine_speed_calc_validity; // rpm validity
	double engine_speed_calc_SOI; // rpm calculated using SOI
	double engine_accel_calc_SOI; // rpm/s calculated using SOI
	double extension_time_ticks_buffer; // us
	double delta_time_stamp_temp; // s

};

#endif