#ifndef IMUMgm_h
#define IMUMgm_h

#include <math.h> // Mathematics
#include "../../Fuelino_Library/IMU_Fuelino.h" // Calibrateable values
#include "../../Fuelino_Library/IMU_Fuelino_cal.h" // Calibrateable values

#define MPU6050_BUFFER_IMU_SIZE 12 // IMU data buffer size
#define MPU6050_BUFFER_SD_WRITE_SIZE (1 + 4 + MPU6050_BUFFER_IMU_SIZE + 2 + 2) // Size of buffer for SD write (header + time + data + temperature + checksum) | 21 bytes
#define MPU6050_SAMPLING_TIME_MS 50

// Calibration Data
/*
#define GX_OFF (short)-100
#define GY_OFF (short)250
#define GZ_OFF (short)-20

#define AX_OFF ((double)AX_MAX + (double)AX_MIN)/(double)2.0 // X acc offset
#define AY_OFF ((double)AY_MAX + (double)AY_MIN)/(double)2.0 // Y acc offset
#define AZ_OFF ((double)AZ_MAX + (double)AZ_MIN)/(double)2.0 // Z acc offset
*/


class IMUMgm_class{

public:

	IMUMgm_class();
	void parse_IMU_message(unsigned char* buffer_temp);
	
	// Raw values from packet
	unsigned int time_ms;
	short ax;
	short ay;
	short az;
	double temperature;
	short gx;
	short gy;
	short gz;

	// Time Calculated
	unsigned int time_ms_old = 0;
	unsigned int time_ms_delta;
	unsigned int time_ms_modulo;
	double time_s = 0.0;
	double time_s_delta = 0.0;

	//double ax_double; // unit: g
	//double ay_double; // unit: g
	//double az_double; // unit: g

	//double gx_double; // unit: deg/s
	//double gy_double; // unit: deg/s
	//double gz_double; // unit: deg/s

	// Calculated by IMU_Fuelino
	double yaw_deg = 0.0;
	double pitch_deg = 0.0;
	double roll_deg = 0.0;
	double yaw_derivative = 0.0;

	// GPS
	double speed_int = 0.0; // temporary value
	double orientation_int = 0.0; // temporary value
	double orientation_int_old = 0.0; // temporary value
	double orientation_delta_IMU_GPS = 0.0; // temporary value
	bool orientation_delta_IMU_GPS_val = false; // temporary value 
	double interpolation_GPS_timer = 0.0; // temporary value (timer)
	double orientation_delta_GPS_timer = 0.0; // temporary value (timer)

	// Fuelino IMU
	double filter_req_pitchroll = 0.0;
	double a_g_norm = 0.0;
	double a_f_delta_norm = 0.0;

	IMUMgm_class* previous = nullptr;
	IMUMgm_class* next = nullptr;
};

extern void export_IMU_data_file(FILE *outfile);
extern void IMU_calculate_yawpitchroll();
extern void IMUMgm_init();
extern void IMU_yaw_linear_regression_correction();
extern IMUMgm_class* IMUMgm_blocks_index;

#endif