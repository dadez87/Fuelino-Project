#include "stdafx.h"

// Data Processing and Filtering constant
#define THROTTLE_MIN (unsigned short)112
#define THROTTLE_MAX (unsigned short)840
#define CUTOFF_MAX_TIME (double)0.15 // in case there is no new injection after this time [s], it will be considered cutoff (0.15 == 800 rpm)
#define DELTA_TIME_US_MIN 10000 // 10ms = 12000 rpm
#define DELTA_TIME_US_MAX 100000 // 100ms = 1200 rpm
#define RPM_MAX_DRPM_DT (double)10000.0 // max physical rpm variation in 1 second

EngineMgm_class::EngineMgm_class(){
	init_old_variables();
}


// Initialize old variables
void EngineMgm_class::init_old_variables(){
	time_stamp_temp_old = 0.0; // time stamp of previous sample
	injection_counter_buffer_old = 0; // injection number at previous sample
	inj_start_tick_last_old = 0; // time of previous start of injection
	time_last_injection = 0.0; // time of last new injection
	engine_speed_calc_old = 0.0; // engine speed calculated at previous sample
	cutoff_mode = false; // this mode becomes active when brake is pressed (injection cut)
	engine_speed_calc_SOI = 0.0;
}


// Parses incoming ECU packet
void EngineMgm_class::parse_ECU_packet(unsigned char* buffer_temp){

	packet_cnt_raw = buffer_temp[1]; // no unit, 0 - 255
	time_stamp_temp_raw = *((unsigned long*)&(buffer_temp[2])); // ms
	injection_counter_buffer_raw = *((unsigned short*)&(buffer_temp[6])); // no unit
	inj_start_tick_last_raw = *((unsigned short*)&(buffer_temp[8])) * 4; // us
	delta_time_tick_buffer_raw = *((unsigned short*)&(buffer_temp[10])) * 4; // us
	delta_inj_tick_buffer_raw = *((unsigned short*)&(buffer_temp[12])) * 4; // us
	throttle_buffer_raw = *((unsigned short*)&(buffer_temp[14])); // 0-1023
	lambda_buffer_raw = *((unsigned short*)&(buffer_temp[16])); // 0-1023
	extension_time_ticks_buffer_raw = *((unsigned short*)&(buffer_temp[18])); // 0.5us
	INJ_exec_time_1_buffer_raw = *((unsigned char*)&(buffer_temp[20])) * 4; // us
	INJ_exec_time_2_buffer_raw = *((unsigned char*)&(buffer_temp[21])) * 4; // us
	digital_inputs_raw = buffer_temp[22]; // no unit. Bit0 = Battery. Bit1 = External DI.

}


// Elaborates raw data
void EngineMgm_class::elaborate_raw_data(){

	time_stamp_temp = (double)time_stamp_temp_raw / (double)1000.0; // s
	if (time_stamp_temp < time_stamp_temp_old) init_old_variables(); // needed when changing file

	lambda_buffer = (double)lambda_buffer_raw * 5.0 / 1023.0;

	// Throttle raw voltage transformed into percentage
	if (throttle_buffer_raw <= THROTTLE_MIN){
		throttle_buffer = 0.0;
	}
	else if (throttle_buffer_raw >= THROTTLE_MAX){
		throttle_buffer = 100.0;
	}
	else{
		throttle_buffer = ((double)(throttle_buffer_raw - THROTTLE_MIN))*(double)100.0 / (double)(THROTTLE_MAX - THROTTLE_MIN);
	}

	delta_time_stamp_temp = time_stamp_temp - time_stamp_temp_old; // delta time stamp (between present and previous sample)

	// Analyze RPM and CUTOFF
	engine_speed_calc = engine_speed_calc_old; // tentative value is old value
	engine_speed_calc_validity = false; // validity tentative
	engine_accel_calc_SOI = 0.0; // tentative value is zero
	if ((injection_counter_buffer_raw == injection_counter_buffer_old)){ // there is no new injection from last time
		if ((time_stamp_temp - time_last_injection) >= CUTOFF_MAX_TIME) { // enough time has passed from last injection
			cutoff_mode = true; // brake was pressed and no new injection is performed
		}
		else { // before cutoff time
			engine_speed_calc_validity = true; // validity
		}
	}
	else{ // there is a new injection
		time_last_injection = time_stamp_temp; // update last injection time
		if (cutoff_mode == true) { // coming out from cutoff
			cutoff_mode = false; // deactivate cutoff mode, since a new injection has been received
		}
		else if ((delta_time_tick_buffer_raw >= DELTA_TIME_US_MIN) && (delta_time_tick_buffer_raw <= DELTA_TIME_US_MAX)){ // ticks range check
			engine_speed_calc = ((double)120000000.0 / (double)delta_time_tick_buffer_raw); // raw rpm calculation
			double boundary_limit = 0.0; // boundary limits first value
			if (delta_time_stamp_temp > 0.0) boundary_limit = (double)RPM_MAX_DRPM_DT * delta_time_stamp_temp; // check
			if (engine_speed_calc > (engine_speed_calc_old + boundary_limit)){
				engine_speed_calc = engine_speed_calc_old + boundary_limit;
			}
			else if (engine_speed_calc < (engine_speed_calc_old - boundary_limit)){
				engine_speed_calc = engine_speed_calc_old - boundary_limit;
			}
			//else { // the speed is not exceeding the boundaries
				engine_speed_calc_validity = true; // validity
			//}
		}

		// Calculate engine speed using SOI information
		if (delta_time_stamp_temp < 0.20) { // check time between packets (must be a bit small of 262.144 ms)
			unsigned int combustion_num_var = (injection_counter_buffer_raw - injection_counter_buffer_old) % 65536; // delta injections
			unsigned int combustion_ticks_var = (inj_start_tick_last_raw - inj_start_tick_last_old) % 262144; // delta ticks (us)
			unsigned int us_per_cycle_ave = combustion_ticks_var / combustion_num_var;
			double engine_speed_calc_SOI_old = engine_speed_calc_SOI; // old speed
			if (us_per_cycle_ave) {
				engine_speed_calc_SOI = (double)120000000.0 / ((double)us_per_cycle_ave);
				engine_accel_calc_SOI = (engine_speed_calc_SOI - engine_speed_calc_SOI_old) / ((double)combustion_ticks_var / (double)1000000.0);
			}
		}

	}

	extension_time_ticks_buffer = (double)extension_time_ticks_buffer_raw / (double)2.0; // us

}