#ifndef CombustionMgm_h
#define CombustionMgm_h

#define INJ_COMB_DATA_SD_COMM_BUFFER_SIZE 28 // buffer size

class CombustionMgm_class {

public:
	CombustionMgm_class();
	void parse_Combustion_message(unsigned char* buffer_temp);

	// Raw signals
	unsigned long time_ms;
	unsigned short injection_counter;
	long long inj_start_ticks;
	long long inj_end_in_ticks;
	long long inj_end_out_ticks;
	unsigned short throttle_raw;
	unsigned short lambda_raw;
	unsigned short INJ_exec_time_1;
	unsigned short INJ_exec_time_2;

	// Calculated signals
	double throttle_perc = 0.0; // V
	double lambda_volt = 0.0; // V
	unsigned long time_between_injections = 0;
	unsigned long time_injection_input = 0;
	unsigned long time_injection_extension = 0;
	unsigned long time_injection_output = 0;
	double injection_increment_perc = 0.0;
	double rpm_cal = 0.0;

	CombustionMgm_class* previous = nullptr;
	CombustionMgm_class* next = nullptr;
};

extern void export_COM_data_file(FILE *outfile); // Exports on file
extern void COM_analyze_Combustion_messages(); // Analyzes all blocks
extern CombustionMgm_class* CombustionMgm_blocks_index; // Starting pointer of the dynamic list

#endif