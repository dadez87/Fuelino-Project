#include "stdafx.h"
#include "IMUMgm.h" // Calibrateable values

#define SPEED_ORIENTATION_CAL_MIN (double)25.0 // km/h
#define SPEED_ORIENTATION_CAL_MAX (double)120.0 // km/h
#define SPEED_RANGE_TIMER_THR (double)1.0 // s
#define ORIENTATION_DELTA_MAX_SLOPE (double)5.0 // deg/s
#define ORIENTATION_DELTA_TIMER_THR (double)1.0 // s
#define IMU_MAX_TIME_BETWEEN_SAMPLES ((double)MPU6050_SAMPLING_TIME_MS/(double)1000.0) * ((double)1.25) // s
#define IMU_GPS_YAW_CORRECTION_MIN_SAMPLES 10 // minimum samples to enable the correction of yaw angle
#define IMU_GPS_ENABLE_YAW_CORRECTION 1

IMUMgm_class* IMUMgm_blocks_index = nullptr;

// Statistical calculation
double regr_a[2][2]; // regression matrix
double regr_ai[2][2]; // regression matrix inverted
double regr_u[2]; // regression vector
double regr_m; // m coefficient
double regr_q; // q coefficient
unsigned int regr_cnt; // counter of samples

// This function is called when a new file is found
void IMUMgm_init() {
	// Initializes accumulator variables for linear regression (IMU GPS delta calculation)
	regr_a[0][0] = (double)0.0;
	regr_a[0][1] = (double)0.0;
	regr_a[1][0] = (double)0.0;
	regr_a[1][0] = (double)0.0;
	regr_ai[0][0] = (double)0.0;
	regr_ai[0][1] = (double)0.0;
	regr_ai[1][0] = (double)0.0;
	regr_ai[1][0] = (double)0.0;
	regr_u[0] = (double)0.0;
	regr_u[1] = (double)0.0;
	regr_m = (double)0.0; // no correction
	regr_q = (double)0.0; // no correction
	regr_cnt = 0; // counter init
	IMU_Fuelino.IMU_init(); // Initializes status variables
}

// Exports IMU data on Excel file
void export_IMU_data_file(FILE *outfile) {
	fprintf(outfile, "Time [ms],");
	fprintf(outfile, "Delta Time [ms],");
	fprintf(outfile, "Modulo [ms],");
	fprintf(outfile, "ax,");
	fprintf(outfile, "ay,");
	fprintf(outfile, "az,");
	fprintf(outfile, "gx,");
	fprintf(outfile, "gy,");
	fprintf(outfile, "gz,");
	fprintf(outfile, "yaw [deg],");
	fprintf(outfile, "pitch [deg],");
	fprintf(outfile, "roll [deg],");
	fprintf(outfile, "Temperature [degC],");
	fprintf(outfile, "yaw derivative [deg/s],");
	fprintf(outfile, "GPS orientation [deg],");
	fprintf(outfile, "GPS speed [deg],");
	fprintf(outfile, "IMU-GPS delta [deg],");
	fprintf(outfile, "\n");
	IMUMgm_class* IMU_block_tmp_now = IMUMgm_blocks_index; // Start from first element
	while (IMU_block_tmp_now != nullptr) {
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms);
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms_delta);
		fprintf(outfile, "%d,", IMU_block_tmp_now->time_ms_modulo);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->ax_double);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->ay_double);
		//fprintf(outfile, "%f,", (float)IMU_block_tmp_now->az_double);
		fprintf(outfile, "%d,", IMU_block_tmp_now->ax);
		fprintf(outfile, "%d,", IMU_block_tmp_now->ay);
		fprintf(outfile, "%d,", IMU_block_tmp_now->az);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gx);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gy);
		fprintf(outfile, "%d,", IMU_block_tmp_now->gz);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->yaw_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->pitch_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->roll_deg);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->temperature);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->yaw_derivative);
		fprintf(outfile, "%f,", (float)(RAD_TO_DEG * IMU_block_tmp_now->orientation_int));
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->speed_int);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->orientation_delta_IMU_GPS);
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->filter_req_pitchroll); // Temporary
		fprintf(outfile, "%f,", (float)IMU_block_tmp_now->a_g_norm); // Temporary
		fprintf(outfile, "\n");
		IMU_block_tmp_now = IMU_block_tmp_now->next;
	}
}

IMUMgm_class::IMUMgm_class(){
	// nothing to initialize
}

// Parses IMU message
void IMUMgm_class::parse_IMU_message(unsigned char* buffer_temp){

	time_ms = *((unsigned int*)&(buffer_temp[1])); // 1
	unsigned short ax_raw = ((unsigned short)(((unsigned short)buffer_temp[6] << 8) | ((unsigned short)buffer_temp[5]))); //
	unsigned short ay_raw = ((unsigned short)(((unsigned short)buffer_temp[8] << 8) | ((unsigned short)buffer_temp[7])));
	unsigned short az_raw = ((unsigned short)(((unsigned short)buffer_temp[10] << 8) | ((unsigned short)buffer_temp[9])));
	unsigned short gx_raw = ((unsigned short)(((unsigned short)buffer_temp[12] << 8) | ((unsigned short)buffer_temp[11])));
	unsigned short gy_raw = ((unsigned short)(((unsigned short)buffer_temp[14] << 8) | ((unsigned short)buffer_temp[13])));
	unsigned short gz_raw = ((unsigned short)(((unsigned short)buffer_temp[16] << 8) | ((unsigned short)buffer_temp[15]))); //
	unsigned short temp_raw = ((unsigned short)(((unsigned short)buffer_temp[18] << 8) | ((unsigned short)buffer_temp[17]))); // 
	ax = *((short*)(&ax_raw));
	ay = *((short*)(&ay_raw));
	az = *((short*)(&az_raw));
	short temp_short = *((short*)(&temp_raw));
	temperature = ((double)temp_short / (double)340.0) + (double)36.53; // Converts to Celsius
	gx = *((short*)(&gx_raw));
	gy = *((short*)(&gy_raw));
	gz = *((short*)(&gz_raw));

	//ax_double = ((double)ax - (double)AX_OFF) * 2.0 / ((double)AX_MAX - (double)AX_MIN); // acceleration [g]
	//ay_double = ((double)ay - (double)AY_OFF) * 2.0 / ((double)AY_MAX - (double)AY_MIN); // acceleration [g]
	//az_double = ((double)az - (double)AZ_OFF) * 2.0 / ((double)AZ_MAX - (double)AZ_MIN); // acceleration [g]

	time_s = (double)time_ms / (double)1000.0;
	time_ms_delta = time_ms - time_ms_old; // Delta time between this sample and previous
	time_s_delta = (double)time_ms_delta / (double)1000.0;
	time_ms_modulo = time_ms % MPU6050_SAMPLING_TIME_MS; // Modulo
}

// Calculates yaw pitch roll starting from all data blocks
void IMU_calculate_yawpitchroll() {
	IMUMgm_class* IMUMgm_block_temp = IMUMgm_blocks_index;
	//data_block_class* ECUGPS_data_block_temp = data_blocks_index; // Start from first element
	GPS_data_block_class* GPS_data_block_temp = GPS_data_blocks_index; // Starting point
	while (IMUMgm_block_temp != nullptr) {
		double time_export_now = IMUMgm_block_temp->time_s; // Time of IMU
		bool interpolation_GPS_ok = false; // temporary value
		bool orientation_int_cal_ok = false; // temporary value
		bool orientation_delta_cal_ok = false; // temporary value

		double max_orientation_variation_deg = IMUMgm_block_temp->time_s_delta * ORIENTATION_DELTA_MAX_SLOPE; // max angle variation from previous sample

		// Finds GPS datablock(s), interpolates their data, and checks stability of GPS data, to evaluate IMU GPS delta
		if (GPS_data_block_temp != nullptr) { // if a GPS block is available
			while (GPS_data_block_temp != nullptr) { // Finds the next GPS element, if present
				if ((GPS_data_block_temp->time_stamp >= time_export_now) && (GPS_data_block_temp->GPS_speed_orientation_val == true)) break;
				GPS_data_block_temp = GPS_data_block_temp->next; // go to the next
			}
			// At the end of this cycle, the GPS time stamp should be higher than the ECU time stamp (with exception to the last, which is null)
			GPS_data_block_class* GPS_data_block_temp2 = GPS_data_block_temp;
			while (GPS_data_block_temp2 != nullptr) { // Finds the previous GPS element, if present
				if ((GPS_data_block_temp2->time_stamp <= time_export_now) && (GPS_data_block_temp2->GPS_speed_orientation_val == true)) break;
				GPS_data_block_temp2 = GPS_data_block_temp2->previous; // go to the previous
			}
			// At the end of this cycle, the GPS time stamp should be lower than the ECU time stamp
			if ((GPS_data_block_temp != nullptr) && (GPS_data_block_temp2 != nullptr)) { // can perform interpolation (not first and not last)
				if ((abs(GPS_data_block_temp->time_stamp - GPS_data_block_temp2->time_stamp) <= MAX_GPS_SPEED_TIME_DIFFERENCE) && (GPS_data_block_temp->GPS_speed_orientation_val == true) && (GPS_data_block_temp2->GPS_speed_orientation_val == true)) { // reliability check
					IMUMgm_block_temp->speed_int = interpolazione(GPS_data_block_temp2->time_stamp, GPS_data_block_temp2->GPS_speed, GPS_data_block_temp->time_stamp, GPS_data_block_temp->GPS_speed, time_export_now);
					if ((IMUMgm_block_temp->speed_int >= SPEED_ORIENTATION_CAL_MIN) && (IMUMgm_block_temp->speed_int <= SPEED_ORIENTATION_CAL_MAX)) { // speed range check
						interpolation_GPS_ok = true; // interpolation was done correctly and data is reliable (no need to reset timer)
						IMUMgm_block_temp->interpolation_GPS_timer += IMUMgm_block_temp->time_s_delta;
						if (IMUMgm_block_temp->interpolation_GPS_timer >= SPEED_RANGE_TIMER_THR) { // speed range timer expired
							IMUMgm_block_temp->orientation_int = interpolazione(GPS_data_block_temp2->time_stamp, GPS_data_block_temp2->GPS_orientation, GPS_data_block_temp->time_stamp, GPS_data_block_temp->GPS_orientation, time_export_now); // GPS interpolation
							if (abs(IMUMgm_block_temp->orientation_int - IMUMgm_block_temp->orientation_int_old) <= max_orientation_variation_deg * DEG_TO_RAD){
								IMUMgm_block_temp->orientation_delta_GPS_timer += IMUMgm_block_temp->time_s_delta;
								orientation_int_cal_ok = true; // delta was small
								if (IMUMgm_block_temp->orientation_delta_GPS_timer >= ORIENTATION_DELTA_TIMER_THR) orientation_delta_cal_ok = true; // OK to calculate delta
							}
						}
					}
				}
			}
		}
		if (interpolation_GPS_ok == false) IMUMgm_block_temp->interpolation_GPS_timer = 0.0; // timer reset (no satisfactory conditions)
		if (orientation_int_cal_ok == false) IMUMgm_block_temp->orientation_delta_GPS_timer = 0.0; // timer reset (no satisfactory conditions)

		// Manages IMU_Fuelino module
		if ((IMUMgm_block_temp->time_s_delta > (double)0.0) && (IMUMgm_block_temp->time_s_delta <= IMU_MAX_TIME_BETWEEN_SAMPLES)) {
			IMU_Fuelino.ax_raw = IMUMgm_block_temp->ax; // Acceleration raw
			IMU_Fuelino.ay_raw = IMUMgm_block_temp->ay;
			IMU_Fuelino.az_raw = IMUMgm_block_temp->az;
			IMU_Fuelino.gx_raw = IMUMgm_block_temp->gx; // Gyroscope raw
			IMU_Fuelino.gy_raw = IMUMgm_block_temp->gy;
			IMU_Fuelino.gz_raw = IMUMgm_block_temp->gz;
			IMU_Fuelino.integration_time = IMUMgm_block_temp->time_s_delta;
			IMU_Fuelino.calculation_task(); // Calculation task
			IMUMgm_block_temp->yaw_deg = RAD_TO_DEG * IMU_Fuelino.yaw_out + (double)360.0*(double)IMU_Fuelino.turns_clockwise; // Outputs
			IMUMgm_block_temp->pitch_deg = RAD_TO_DEG * IMU_Fuelino.pitch_out;
			IMUMgm_block_temp->roll_deg = RAD_TO_DEG * IMU_Fuelino.roll_out;
			IMUMgm_block_temp->filter_req_pitchroll = IMU_Fuelino.filter_req_pitchroll;
			IMUMgm_block_temp->a_g_norm = IMU_Fuelino.a_g_norm;
			IMUMgm_block_temp->a_f_delta_norm = IMU_Fuelino.a_f_delta_norm;
			if (IMUMgm_block_temp->previous != nullptr) {
				double yaw_deg_old_tmp = IMUMgm_block_temp->previous->yaw_deg;
				IMUMgm_block_temp->yaw_derivative = (IMUMgm_block_temp->yaw_deg - yaw_deg_old_tmp) / IMUMgm_block_temp->time_s_delta; // derivative (deg/second)
				if (orientation_delta_cal_ok == true) { // Calculate delta between IMU and GPS yaw
					if (abs(IMUMgm_block_temp->yaw_derivative) <= max_orientation_variation_deg) {
						IMUMgm_block_temp->orientation_delta_IMU_GPS = RAD_TO_DEG * IMU_Fuelino.yaw_out - RAD_TO_DEG * IMUMgm_block_temp->orientation_int;
						if (IMUMgm_block_temp->orientation_delta_IMU_GPS < (double)0.0) IMUMgm_block_temp->orientation_delta_IMU_GPS += (double)360.0;
						IMUMgm_block_temp->orientation_delta_IMU_GPS_val = true; // delta calculation is valid
						regr_u[0] += (IMUMgm_block_temp->orientation_delta_IMU_GPS) * (IMUMgm_block_temp->time_s); // x0y0
						regr_a[0][0] += (IMUMgm_block_temp->time_s) * (IMUMgm_block_temp->time_s); // x0^2
						regr_a[0][1] += IMUMgm_block_temp->time_s; // x0
						regr_u[1] += IMUMgm_block_temp->orientation_delta_IMU_GPS; // y0
						regr_a[1][0] += IMUMgm_block_temp->time_s; // x0
						regr_a[1][1] += (double)1.0; // 1
						regr_cnt++; // counter increase
					}
				}
			}
		}

		// Save temporary value in next block
		if (IMUMgm_block_temp->next != nullptr) {
			IMUMgm_block_temp->next->interpolation_GPS_timer = IMUMgm_block_temp->interpolation_GPS_timer; // old timer
			IMUMgm_block_temp->next->orientation_delta_GPS_timer = IMUMgm_block_temp->orientation_delta_GPS_timer; // old timer
			IMUMgm_block_temp->next->orientation_int_old = IMUMgm_block_temp->orientation_int; // old orientation GPS
			IMUMgm_block_temp->next->yaw_deg = IMUMgm_block_temp->yaw_deg; // temporary
			IMUMgm_block_temp->next->pitch_deg = IMUMgm_block_temp->pitch_deg; // temporary
			IMUMgm_block_temp->next->roll_deg = IMUMgm_block_temp->roll_deg; // temporary
		}

		IMUMgm_block_temp = IMUMgm_block_temp->next; // go to next element
	}
}

// Linear regression calculates the discrepancy between IMU and GPS
void IMU_yaw_linear_regression_correction() {
	printf("IMU GPS yaw offset calculation. Samples: %d (min=%d).\n", regr_cnt, (unsigned int)IMU_GPS_YAW_CORRECTION_MIN_SAMPLES);
	if (regr_cnt >= IMU_GPS_YAW_CORRECTION_MIN_SAMPLES) {
		double det_temp = regr_a[0][0] * regr_a[1][1] - regr_a[0][1] * regr_a[1][0]; // determinante
		regr_ai[0][0] = regr_a[1][1] / det_temp;
		regr_ai[0][1] = -regr_a[0][1] / det_temp;
		regr_ai[1][0] = -regr_a[1][0] / det_temp;
		regr_ai[1][1] = regr_a[0][0] / det_temp;
		regr_m = regr_ai[0][0] * regr_u[0] + regr_ai[0][1] * regr_u[1];
		regr_q = regr_ai[1][0] * regr_u[0] + regr_ai[1][1] * regr_u[1];
		if (regr_q < (double)-180.0) {
			regr_q += (double)360.0;
		}
		else if (regr_q >(double)180.0) {
			regr_q -= (double)360.0;
		}
		//printf("a11=%f, a12=%f, a21=%f, a22=%f, u1=%f, u1=%f.\n", (float)regr_a[0][0], (float)regr_a[0][1], (float)regr_a[1][0], (float)regr_a[1][1], (float)regr_u[0], (float)regr_u[1]);
		//printf("ai11=%f, ai12=%f, ai21=%f, ai22=%f.\n", (float)regr_ai[0][0], (float)regr_ai[0][1], (float)regr_ai[1][0], (float)regr_ai[1][1]);
		printf("Coefficients: m= %f deg/s, q= %f deg. ", (float)regr_m, (float)regr_q);
		IMUMgm_class* IMUMgm_block_temp = IMUMgm_blocks_index;
		if (IMU_GPS_ENABLE_YAW_CORRECTION) {
			while (IMUMgm_block_temp != nullptr) {
				IMUMgm_block_temp->yaw_deg -= (regr_m*(IMUMgm_block_temp->time_s) + regr_q); // yaw angle correction
				IMUMgm_block_temp = IMUMgm_block_temp->next; // go to next element
			}
			printf("Correction done.\n");
		}
		else {
			printf("Correction not enabled.\n");
		}
	}
	else {
		printf("Not enough samples acquired.\n");
	}
}